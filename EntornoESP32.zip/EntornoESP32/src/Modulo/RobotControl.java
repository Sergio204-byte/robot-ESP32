
package Modulo;
import com.fazecast.jSerialComm.SerialPort;

import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class RobotControl extends JFrame {

    private SerialPort puertoGuante;
    private SerialPort puertoAuto;

    private JComboBox<String> comboGuante;
    private JComboBox<String> comboAuto;
    private JTextArea consola;
    private JButton botonConectar;

    public RobotControl() {
        //SECCION DE LA INTERFAZ
        setTitle("Control de Robot con Guante ESP32");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        consola = new JTextArea();
        consola.setEditable(false);
        add(new JScrollPane(consola), BorderLayout.CENTER);

        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(new GridLayout(2, 2));

        comboGuante = new JComboBox<>();
        comboAuto = new JComboBox<>();
        botonConectar = new JButton("Conectar");

        panelSuperior.add(new JLabel("Puerto ESP32 Guante:"));
        panelSuperior.add(comboGuante);
        panelSuperior.add(new JLabel("Puerto ESP32 Auto:"));
        panelSuperior.add(comboAuto);

        add(panelSuperior, BorderLayout.NORTH);
        add(botonConectar, BorderLayout.SOUTH);

        listarPuertos();

        botonConectar.addActionListener(e -> conectar());

        setVisible(true);
    }

    private void listarPuertos() {
        SerialPort[] puertos = SerialPort.getCommPorts();
        for (SerialPort puerto : puertos) {
            comboGuante.addItem(puerto.getSystemPortName());
            comboAuto.addItem(puerto.getSystemPortName());
            
            //MUESTRA Y CONFIRMA LA LISTA DE PUERTOS TANTO CON EL GUANTO COMO CON EL AUTO
        }
    }

    private void conectar() {
        String nombreGuante = (String) comboGuante.getSelectedItem();
        String nombreAuto = (String) comboAuto.getSelectedItem();

        puertoGuante = SerialPort.getCommPort(nombreGuante);
        puertoAuto = SerialPort.getCommPort(nombreAuto);

        puertoGuante.setBaudRate(9600); //TRANSMICION ESTABLECIDA DE 9600 BAUDIOS
        puertoAuto.setBaudRate(9600); //TRANSMICION ESTABLECIDA DE 9600 BAUDIOS

        if (puertoGuante.openPort() && puertoAuto.openPort()) {
            consola.append("CONEXION ESTABLECIDA CON LOS PUERTOS ESP32");

            Thread hiloLectura = new Thread(() -> {
                Scanner scanner = new Scanner(puertoGuante.getInputStream());
                while (true) {
                    if (scanner.hasNextLine()) {
                        String linea = scanner.nextLine();
                        consola.append("Guante: " + linea + "\n");

                        String comando = interpretarMovimiento(linea);
                        if (comando != null) {
                            enviarComandoAlAuto(comando);
                            consola.append("Comando enviado al auto: " + comando);
                        }
                    }
                }
            });

            hiloLectura.start();
        } else {
            consola.append("ERROR CONEXION NO ESTABLECIDA");
        }
    }

    private String interpretarMovimiento(String datos) {
        try {
            // Espera formato "X:0.5,Y:0.1,Z:9.8" para comenzar con la obtencion de datos
            String[] partes = datos.split(",");
            double x = Double.parseDouble(partes[0].split(":")[1]);
            double y = Double.parseDouble(partes[1].split(":")[1]);

            if (y < -0.5) return "D";   // Adelante
            if (y > 0.5)  return "RV";   // Atrás
            if (x > 0.5)  return "R";   // Derecha
            if (x < -0.5) return "L";   // Izquierda

            return "S"; // ALTO

        } catch (Exception e) {
            consola.append("NO SE HAN INTERPRETADO LOS DATOS " + datos );
            return null;
        }
    }

    private void enviarComandoAlAuto(String comando) {
        byte[] buffer = comando.getBytes();
        puertoAuto.writeBytes(buffer, buffer.length);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(RobotControl::new);
    }
}
